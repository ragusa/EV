function u0 = IC_exponential(x)

n = length(x);
u0 = zeros(n,1);

for i = 1:n
    u0(i) = exp(-200*(x(i)-0.5)^2);
end

end