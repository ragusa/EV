function p = flux_coefficients(fd,fm,u,n)

p = zeros(n,n);
for i = 1:n
    for j = 1:n
        if (u(j) ~= u(i))
            p(i,j) = (fd(i,j) + fm(i,j))/(u(j) - u(i));
        else
            p(i,j) = 0.0;
        end
    end
end

end