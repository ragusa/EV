function f_lim = correction_flux(fprime,frem,m,dt,L,u,n,limiting_option)

% Pplus  = zeros(n,1);
% Pminus = zeros(n,1);
% Qminus = zeros(n,1);
% Qplus  = zeros(n,1);
% for edge = 1:n-1
%     i = edge; % upwind node
%     j = i+1;  % downwind node
%     Pplus(i)  = Pplus(i)  + max(0,f(i,j));
%     Pminus(i) = Pminus(i) + min(0,f(i,j));
%     Pplus(j)  = Pplus(j)  + max(0,-frem(i,j));
%     Pminus(j) = Pminus(j) + min(0,-frem(i,j));
%     
%     Qplus(i)  = Qplus(i)  + (m(i,j)/dt + L(i,j))*max(0,u(j) - u(i));
%     Qminus(i) = Qminus(i) + (m(i,j)/dt + L(i,j))*min(0,u(j) - u(i));
%     Qplus(j)  = Qplus(j)  + (m(j,i)/dt + L(j,i))*max(0,u(i) - u(j));
%     Qminus(j) = Qminus(j) + (m(j,i)/dt + L(j,i))*min(0,u(i) - u(j));
% end

% P vectors
Pplus  = zeros(n,1);
Pminus = zeros(n,1);
for i=1:n
    for j = 1:n
        Pplus(i)  = Pplus(i)  + max(0,fprime(i,j)) + max(0,frem(i,j));
        Pminus(i) = Pminus(i) + min(0,fprime(i,j)) + min(0,frem(i,j));
    end
end

% Q vectors
Qminus = zeros(n,1);
Qplus  = zeros(n,1);
for i=1:n
    for j = 1:n
        Qplus(i)  = Qplus(i)  + (m(i,j)/dt + L(i,j))*max(0,u(j) - u(i));
        Qminus(i) = Qminus(i) + (m(i,j)/dt + L(i,j))*min(0,u(j) - u(i));
    end
end

% R vectors
Rminus = zeros(n,1);
Rplus  = zeros(n,1);
for i = 1:n
    if (Pplus(i) ~= 0)
        Rplus(i)  = min(1, Qplus(i) / Pplus(i));
    else
        Rplus(i) = 1.0;
    end
    if (Pminus(i) ~= 0)
        Rminus(i)  = min(1, Qminus(i) / Pminus(i));
    else
        Rminus(i) = 1.0;
    end    
end
% set R+ and R- = 1 for Dirichlet node as Kuzmin recommended. This
% prevents limiting coefficient from automatically being 0 for j in the
% support of i
Rplus(1)  = 1.0;
Rminus(1) = 1.0;

switch limiting_option
    case 0 % no correction: all limiting coefficients zero
        Rplus  = zeros(n,1);
        Rminus = zeros(n,1);
    case 1 % full correction; all limiting coefficients one
        Rplus  = ones(n,1);
        Rminus = ones(n,1);
    case 2 % normal correction; do nothing
    otherwise
        error('Invalid limiting option');
end

% limit fluxes
f_lim = zeros(n,1);
for i = 1:n
    for j = 1:n
        k = min(i,j);
        if (fprime(i,j) > 0)
            fprime_lim = Rplus(k)*fprime(i,j);
            f_lim(i) = f_lim(i) + fprime_lim;
        else
            fprime_lim = Rminus(k)*fprime(i,j);
            f_lim(i) = f_lim(i) + fprime_lim;
        end
        
        if (frem(i,j) > 0)
            frem_lim = min(Rplus(i),Rminus(j))*frem(i,j);
            f_lim(i) = f_lim(i) + frem_lim;
        else
            frem_lim = min(Rminus(i),Rplus(j))*frem(i,j);
            f_lim(i) = f_lim(i) + frem_lim;
        end
    end
end

return
end