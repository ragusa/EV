function f = flux(p,u,n)

f = zeros(n,n);
for i = 1:n
    for j = 1:n
        f(i,j) = min(0,p(i,j))*(u(j) - u(i));
    end
end

end