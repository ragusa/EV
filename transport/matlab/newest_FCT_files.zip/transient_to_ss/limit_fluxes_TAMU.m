function flim = limit_fluxes_TAMU(F,u_old,u_new,ML,W_max,W_min,AL,b,dt,theta)

n = length(u_old);

flim   = zeros(n,1);
Pplus  = zeros(n,1);
Pminus = zeros(n,1);
Rminus = zeros(n,1);
Rplus  = zeros(n,1);
Qminus = zeros(n,1);
Qplus  = zeros(n,1);

% P vectors
for i=1:n   
    Pplus(i) = sum(max(0,F(i,:)));
    Pminus(i)= sum(min(0,F(i,:)));
end

% Q vectors
for i = 1:n
    Qplus(i)  = (ML(i,i) + theta*dt*AL(i,i))*W_max(i)...
        - (ML(i,i) - (1-theta)*dt*AL(i,i))*u_old(i)...
        + dt*AL(i,:)*(theta*u_new + (1-theta)*u_old)...
        - dt*AL(i,i)*(theta*u_new(i) + (1-theta)*u_old(i))...
        - dt*b(i);
    Qminus(i) = (ML(i,i) + theta*dt*AL(i,i))*W_min(i)...
        - (ML(i,i) - (1-theta)*dt*AL(i,i))*u_old(i)...
        + dt*AL(i,:)*(theta*u_new + (1-theta)*u_old)...
        - dt*AL(i,i)*(theta*u_new(i) + (1-theta)*u_old(i))...
        - dt*b(i);
end

% R vectors
for i = 1:n
    if (Pplus(i) ~= 0)
        Rplus(i) = min(1, Qplus(i)/Pplus(i));
    else
        Rplus(i) = 1.0;
    end
    if (Pminus(i) ~= 0)
        Rminus(i) = min(1, Qminus(i)/Pminus(i));
    else
        Rminus(i) = 1.0;
    end
end
% set R+ and R- = 1 for Dirichlet node as Kuzmin recommended. This
% prevents L_ij from automatically being 0 for j in the support of i
Rplus(1)  = 1.0;
Rminus(1) = 1.0;

% limiting coefficients
for i=1:n
    for j=1:n
        if(F(i,j)>=0)
            flim(i) = flim(i) + min(Rplus(i),Rminus(j))*F(i,j);
        else
            flim(i) = flim(i) + min(Rminus(i),Rplus(j))*F(i,j);
        end
    end
end

return
end