function fd = diffusive_flux(d,u,n)

fd = zeros(n,n);
for i = 1:n
    for j = 1:n
        fd(i,j) = d(i,j)*(u(i) - u(j));
    end
end

end