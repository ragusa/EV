close all; clc;
%% Introductory Comments
% Solves the transport equation:
%
% du/dt + omega.grad(u) + sigma*u = q
%
% using the defect correction for the theta time-integration scheme,
% general-purpose FCT scheme given in Section 5 of
%
% On the design of general-purpose flux limiters for finite element
% schemes. I. Scalar convection, by D. Kuzmin, Journal of Computational
% Physics 219 (2009) 513-531.

%% User Options

nel_init = 50; % number of elements in first cycle
n_cycle  = 1;  % number of refinement cycles

problemID = 1; % 1 = smooth exponential decay
               % 2 = sharp exponential decay; heterogenous sigma

theta = 1.0; % theta for theta time integration scheme:
             % 0: forward (explicit) euler
             % 1: backward (implicit) euler

ss_tol = 1.0e-4; % steady-state tolerance
n_max = 100;      % maximum number of time steps
CFL = 50.0;       % CFL number

limiting_option = 2; % 0 = set limiting coefficients to 0 (no correction)
                     % 1 = set limiting coefficients to 1 (full correction)
                     % 2 = use Kuzmin's old limiter
                     % 3 = use Kuzmin's general-purpose limiter
                     % 4 = use TAMU's limiter
m_max = 30;    % maximum number of defect-correction iterations
dc_tol = 1e-4; % defect-correction tolerance for discrete L2 norm

plot_low_order  = false; % plot low-order transient?
plot_high_order = false; % plot high-order transient?
plot_FCT        = false; % plot FCT transient?

%% Setup

% determine problem parameters from ID
switch problemID
    case 1
        len=10;         % length of domain
        omega=1.0;      % omega
        sigma = @(x) 1; % sigma
        src=0;          % source
        inc=1;          % incoming flux
        speed=1;
    case 2
        len=10;
        omega=1.0;
        sigma = @hetero_sigma;
        src=0;
        inc=1;
        speed=1;
    otherwise
        error('Invalid problem ID');
end

%% Solution

h = zeros(n_cycle,1); % mesh size for each cycle

% L2 errors for each cycle
uL_err   = zeros(n_cycle,1);
uH_err   = zeros(n_cycle,1);
uFCT_err = zeros(n_cycle,1);

% loop over refinement cycles
for cycle = 1:n_cycle
    nel = nel_init * 2^(cycle-1); % number of elements
    n_dof = nel + 1;              % number of dofs
    h(cycle) = len/nel;           % mesh size
    
    % build matrices
    [MC,ML,K,D,b]=build_matrices(len,nel,omega,sigma,src);
    L = K+D;       % low-order matrix
    ML = diag(ML); % lumped mass matrix
    AL = -(K+D);   % low-order steady-state system matrix
    AH = -K;       % high-order steady-state system matrix
    
    % compute dt using CFL condition, even for implicit, just so that time
    % steps will be equal between explicit and implicit, for comparison
    dt = CFL*ML(1,1)/AL(1,1);
    for i = 2:n_dof
        dt = min(dt, CFL*ML(i,i)/AL(i,i));
    end
    
    % define low-order and high-order transient sytem matrices to be inverted
    ALtr = ML - dt*theta*L;
    AHtr = MC - dt*theta*K;
    % compute modified transient sytem matrix for Dirichlet BC
    ALtr_mod = ALtr;
    ALtr_mod(1,:)=0; ALtr_mod(1,1)=1;
    % compute modified transient sytem matrix for Dirichlet BC
    AHtr_mod = AHtr;
    AHtr_mod(1,:)=0; AHtr_mod(1,1)=1;
    
    dc_preconditioner = ALtr_mod; % preconditioner matrix for defect-correction
    
    % initial conditions for pseudotransient (equal to exact steady-state solution)
    x = linspace(0,len,nel+1);
    u0 = zeros(n_dof,1);
    
    % low-order solve
    %======================================================================
    fprintf('\tComputing low-order solution...\n');
    u_old = u0;
    t = 0;
    for n = 1:n_max
        fprintf('\t\tTime step %i: t = %f->%f',n,t,t+dt);
        % compute rhs
        rhs = (ML - (1-theta)*dt*AL)*u_old + dt*b;
        % modify rhs for Dirichlet BC
        rhs(1) = inc;
        % solve modified system
        uL = ALtr_mod \ rhs;
        % test steady-state convergence
        ss_err = norm(uL-u_old,2);
        fprintf(' norm(u_new - u_old) = %e\n',ss_err);
        converged = ss_err < ss_tol;
        if (converged)
            fprintf('\t\tReached steady-state at time step %i\n',n);
            break;
        end
        % plot
        if (plot_low_order)
            plot(x,uL);
            legend('Low-order');
            pause(0.1);
        end
        % reset u_old
        u_old = uL;
        t = t+dt;
    end

    % high-order solve
    %======================================================================
    if (theta == 1)
        fprintf('\tComputing high-order solution...\n');
        u_old = u0;
        t = 0;
        for n = 1:n_max
            fprintf('\t\tTime step %i: t = %f->%f',n,t,t+dt);
            % compute rhs
            rhs = (MC - (1-theta)*dt*AH)*u_old + dt*b;
            % modify rhs for Dirichlet BC
            rhs(1) = inc;
            % solve modified system
            uH = AHtr_mod \ rhs;
            % test steady-state convergence
            ss_err = norm(uH-u_old,2);
            fprintf(' norm(u_new - u_old) = %e\n',ss_err);
            converged = ss_err < ss_tol;
            if (converged)
                fprintf('\t\tReached steady-state at time step %i\n',n);
                break;
            end
            % plot
            if (plot_high_order)
                plot(x,uH);
                legend('High-order');
                pause(0.1);
            end
            % reset u_old
            u_old = uH;
            t = t+dt;
        end
    end
    
    % FCT solve
    %======================================================================
    fprintf('\tComputing FCT solution...\n');
    u_old = u0;
    uFCT = u0;
    t = 0;
    for n = 1:n_max
        fprintf('\t\tTime step %i: t = %f->%f\n',n,t,t+dt);
        % compute auxiliary solution
        %----------------
        % compute rhs
        rhs = (ML - (1-theta)*dt*AL)*u_old + (1-theta)*dt*b;
        % solve for aux. solution
        u_aux = ML \ rhs;
        
        % low-order solve
        %----------------
        % compute rhs
        rhs = (ML - (1-theta)*dt*AL)*u_old + dt*b;
        % modify rhs for Dirichlet BC
        rhs(1) = inc;
        % solve modified system
        uL_FCT_loop = ALtr_mod \ rhs;
        
        % high-order solve
        %----------------
        % compute rhs
        rhs = (MC - (1-theta)*dt*AH)*u_old + dt*b;
        % modify rhs for Dirichlet BC
        rhs(1) = inc;
        % solve modified system
        uH_FCT_loop = AHtr_mod \ rhs;
        
        % compute the upper and lower bound for TAMU max principle
        [W_max,W_min] = max_principle_bounds_TAMU(u_old,uL_FCT_loop,dt,ML,AL,b,theta);
        
        % solve for new step solution using defect-correction
        dc_converged = 0; % flag for convergence of defect-correction
        for m = 1:m_max
            % compute limited fluxes
            switch limiting_option
                case 0 % no correction
                    flim = zeros(n_dof,1);
                case 1 % full correction (no limiting)
                    F = flux_correction_matrix(u_old,uH,dt,D,MC,theta);
                    flim = sum(F,2);
                case 2 % Kuzmin's old limiter
                    F = flux_correction_matrix(u_old,uH,dt,D,MC,theta);
                    flim = limit_fluxes_old(F,u_aux,ML);
                case 3 % Kuzmin's general-purpose limiter
                    dudt    = (uH_FCT_loop - u_old)/dt;
                    Fd      = diffusive_flux(D,uH_FCT_loop,n_dof);        % Eq. (7)
                    Fm      = mass_flux(MC,dudt,n_dof);                   % Eq. (10)
                    p       = flux_coefficients(Fd,Fm,uH_FCT_loop,n_dof); % Eq. (31)
                    F       = flux(p,uH_FCT_loop,n_dof);                  % Eq. (31)
                    Fprime  = prelimited_flux(p,L,uH_FCT_loop,n_dof);     % Eq. (22)
                    Frem    = F - Fprime; % remainder flux, see Section 4.3, step 1.
                    flim    = dt*limit_fluxes_GP(Fprime,Frem,MC,dt,L,uH_FCT_loop,n_dof); % Eq. (35)
                case 4 % TAMU's limiter
                    flim = limit_fluxes_TAMU(...
                        F,u_old,uFCT,ML,W_max,W_min,AL,b,dt,theta);
                otherwise
                    error('Invalid limiting option');
            end
            
            rhs = (ML + (1-theta)*dt*L)*u_old + dt*b + flim; % part of Eq. (39)
            rhs(1) = inc;               % modify for Dirichlet BC
            r =  rhs - ALtr_mod*uFCT;   % Eq. (39), modified for Dirichlet BC
            
            du = dc_preconditioner \ r; % Eq. (43)
            uFCT = uFCT + du;           % Eq. (44)
            L2norm = norm(du,2);
            fprintf('\t\t\tDefect correction iteration %i error: %e\n',m,L2norm);
            if (L2norm < dc_tol)
                dc_converged = 1;
                break;
            end
        end
        % terminate if defect-correction did not converge
        if (~dc_converged)
            error('Defect correction did not converge');
        end
        % test steady-state convergence
        ss_err = norm(uFCT-u_old,2);
        fprintf('\t\t\tnorm(u_new - u_old) = %e\n',ss_err);
        converged = ss_err < ss_tol;
        if (converged)
            fprintf('\t\tReached steady-state at time step %i\n',n);
            break;
        end
        % plot
        if (plot_FCT)
            plot(x,uFCT);
            legend('FCT');
            pause(0.1);
        end
        % reset u_old
        u_old = uFCT;
        t = t+dt;
    end
end

%% Convergence Table

% fprintf('\nLow-order Convergence:\n')
% for cycle = 1:n_cycle
%     if (cycle == 1)
%         fprintf('Cycle %i: L2 error = %e\n',cycle,uL_err(cycle));
%     else
%         rate = log(uL_err(cycle)/uL_err(cycle-1))/log(h(cycle)/h(cycle-1));
%         fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uL_err(cycle),rate);
%     end
% end
% fprintf('\nHigh-order Convergence:\n')
% for cycle = 1:n_cycle
%     if (cycle == 1)
%         fprintf('Cycle %i: L2 error = %e\n',cycle,uH_err(cycle));
%     else
%         rate = log(uH_err(cycle)/uH_err(cycle-1))/log(h(cycle)/h(cycle-1));
%         fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uH_err(cycle),rate);
%     end
% end
% fprintf('\nFCT Convergence:\n')
% for cycle = 1:n_cycle
%     if (cycle == 1)
%         fprintf('Cycle %i: L2 error = %e\n',cycle,uFCT_err(cycle));
%     else
%         rate = log(uFCT_err(cycle)/uFCT_err(cycle-1))/log(h(cycle)/h(cycle-1));
%         fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uFCT_err(cycle),rate);
%     end
% end

%% Plot

figure(1); clf; hold on;

% plot exact solution
x_exact = linspace(0,len,1000);
u_exact = exact_solution(problemID,x_exact,sigma,src,inc,omega,speed);
plot(x_exact,u_exact,'k-');
legend_entries = char('Exact');

% plot low-order solution
plot(x,uL,'r-s');
legend_entries = char(legend_entries,'Low-order');

% plot high-order solution
plot(x,uH,'b-+');
legend_entries = char(legend_entries,'High-order');

% plot FCT solution
plot(x,uFCT,'g-x');
switch limiting_option
    case 0 % no correction
        limiter_string = 'no correction';
    case 1 % full correction (no limiting)
        limiter_string = 'not limited';
    case 2 % Kuzmin's old limiter
        limiter_string = 'Kuzmin old limiter';
    case 3 % Kuzmin's general-purpose limiter
        limiter_string = 'Kuzmin general-purpose limiter';
    case 4 % TAMU limiter
        limiter_string = 'TAMU limiter';
    otherwise
        error('Invalid limiting option');
end
FCT_legend_string = ['FCT, ',limiter_string];
legend_entries = char(legend_entries,FCT_legend_string);

% legend
legend(legend_entries,'Location','Best');