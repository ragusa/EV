function f = prelimited_flux(p,L,u,n)

f = zeros(n,n);
for i = 1:n
    for j = 1:n
        f(i,j) = min(-p(i,j),L(j,i))*(u(i) - u(j));
    end
end

end