function sigma = hetero_sigma(x_center)

if (x_center < 5)
    sigma = 0;
else
    sigma = 10;
end

end