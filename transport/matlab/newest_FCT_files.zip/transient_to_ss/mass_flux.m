function fm = mass_flux(m,dudt,n)

fm = zeros(n,n);
for i = 1:n
    for j = 1:n
        fm(i,j) = m(i,j)*(dudt(i) - dudt(j));
    end
end

end