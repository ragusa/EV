close all; clear; clc;
%% Introduction

% Solves a steady-state transport equation:
%   -(K  )*u = b (high-order system)
%   -(K+D)*u = b (low-order system)

%% User Options

nel_init = 50; % number of elements in first cycle
n_cycle  = 1;  % number of refinement cycles

problemID = 1; % 1 = smooth exponential decay
               % 2 = sharp exponential decay; heterogenous sigma

limiting_option = 2; % 0 = set limiting coefficients to 0 (no correction)
                     % 1 = set limiting coefficients to 1 (full correction)
                     % 2 = compute Kuzmin's limiting coefficients
                     % 3 = compute TAMU's limiting coefficients
max_iter = 100; % maximum number of iterations for implicit FCT
tol = 1.0e-6; % defect correction convergence tolerance

%% Setup

% determine problem parameters from ID
switch problemID
    case 1 % smooth problem
        len=10;         % length of domain
        omega=1.0;      % omega
        sigma = @(x) 1; % sigma
        src=0;          % source
        inc=1;          % incoming flux
    case 2
        len=10;
        omega=1.0;
        sigma = @hetero_sigma;
        src=0;
        inc=1;
    otherwise
        error('Invalid problem ID');
end

h = zeros(n_cycle,1); % mesh size for each cycle

% L2 errors for each cycle
uL_err   = zeros(n_cycle,1);
uH_err   = zeros(n_cycle,1);
uFCT_err = zeros(n_cycle,1);

%% Solution

% loop over refinement cycles
for cycle = 1:n_cycle
    nel = nel_init * 2^(cycle-1); % number of elements
    n_dof = nel + 1;              % number of dofs
    h(cycle) = len/nel;           % mesh size
    fprintf('Cycle %i: n_dof = %i\n',cycle,n_dof);
    
    % build matrices
    [MC,ML,K,D,b] = build_matrices(len,nel,omega,sigma,src);
    ML = diag(ML);
    AH = -(K  );    % high-order steady-state system matrix
    AL = -(K+D);    % low-order steady-state system matrix
    
    % compute modified high-order sytem matrix for Dirichlet BC
    AH_mod = AH;
    AH_mod(1,:)=0; AH_mod(1,1)=1;
    % compute modified low-order sytem matrix for Dirichlet BC
    AL_mod = AL;
    AL_mod(1,:)=0; AL_mod(1,1)=1;
    % compute modified rhs
    b_mod = b;
    b_mod(1) = inc;
    
    % low-order solve
    %======================================================================
    fprintf('\tComputing low-order solution...\n');
    uL = AL_mod \ b_mod;
    
    % high-order solve
    %======================================================================
    fprintf('\tComputing high-order solution...\n');
    uH = AH_mod \ b_mod;
    
    % FCT solve
    %======================================================================
    fprintf('\tComputing FCT solution...\n');
%     ALnew = AL;
%     for i = 1:n_dof
%         for j = 1:n_dof
%             if (j == i)
%                 if (i > 1)
%                     ALnew(i,j) = ALnew(i,j) - D(i,i-1);
%                 end
%             elseif (j < i)
%                 ALnew(i,j) = ALnew(i,j) + D(i,j);
%             end
%         end
%     end
%     ALnew(1,:) = 0.0; ALnew(1,1) = 1.0;
%     rhs = zeros(n_dof,1); rhs(1) = inc;
%     uFCT = ALnew \ rhs;
    uFCT = zeros(n_dof,1);
    converged = 0; % convergence flag
    for iter = 1:max_iter
        % FCT solve
        %----------------
        % compute flux correction matrix
        F = flux_correction_matrix(uH,D);
        % compute limiting coefficients
        switch limiting_option
            case 0 % no correction
                Flim = 0*F;
            case 1 % full correction (no limiting)
                Flim = F;
            case 2 % normal limiting via Kuzmin's limiter
                kuzmin_or_tamu = 1; % 1 = Kuzmin
                Flim = limiting_coefficients(F,uFCT,AL,kuzmin_or_tamu);
            case 3 % normal limiting via TAMU's limiter
                kuzmin_or_tamu = 2; % 2 = TAMU
                Flim = limiting_coefficients(F,uFCT,AL,kuzmin_or_tamu);
            otherwise
                error('Invalid limiting option');
        end
        % compute correction rhs
        rhs = b + sum(Flim,2);
        % modify rhs for Dirichlet BC
        rhs(1) = inc;
        % compute residual
        res = rhs - AL_mod*uFCT;
        % test convergence
        resnorm = norm(res,2);
        fprintf('\t\tIteration %i: residual error = %e\n',iter,resnorm);
        converged = resnorm < tol;
        if (converged)
            fprintf('\t\tConverged at iteration %i\n',iter);
            break;
        end
        % solve modified system
        uFCT = uFCT + AL_mod \ res;
    end
    
    if (~converged)
        error('\t\tSolution did not converged in %i iterations\n',max_iter);
    end
    
    % compute error
    %======================================================================
    x = linspace(0,len,nel+1);
    uL_err(cycle)   = compute_error(uL,x);
    uH_err(cycle)   = compute_error(uH,x);
    uFCT_err(cycle) = compute_error(uFCT,x);
end

%% Convergence Rates

fprintf('\nLow-order Convergence:\n')
for cycle = 1:n_cycle
    if (cycle == 1)
        fprintf('Cycle %i: L2 error = %e\n',cycle,uL_err(cycle));
    else
        rate = log(uL_err(cycle)/uL_err(cycle-1))/log(h(cycle)/h(cycle-1));
        fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uL_err(cycle),rate);
    end
end
fprintf('\nHigh-order Convergence:\n')
for cycle = 1:n_cycle
    if (cycle == 1)
        fprintf('Cycle %i: L2 error = %e\n',cycle,uH_err(cycle));
    else
        rate = log(uH_err(cycle)/uH_err(cycle-1))/log(h(cycle)/h(cycle-1));
        fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uH_err(cycle),rate);
    end
end
fprintf('\nFCT Convergence:\n')
for cycle = 1:n_cycle
    if (cycle == 1)
        fprintf('Cycle %i: L2 error = %e\n',cycle,uFCT_err(cycle));
    else
        rate = log(uFCT_err(cycle)/uFCT_err(cycle-1))/log(h(cycle)/h(cycle-1));
        fprintf('Cycle %i: L2 error = %e, rate = %f\n',cycle,uFCT_err(cycle),rate);
    end
end

%% Plot

figure(1); clf; hold on;

% plot exact solution
x_exact = linspace(0,len,1000);
u_exact = exact_solution(problemID,x_exact,sigma,src,inc,omega);
plot(x_exact,u_exact,'k-');
legend_entries = char('Exact');

% plot low-order solution
plot(x,uL,'r-s');
legend_entries = char(legend_entries,'Low-order');

% plot high-order solution
plot(x,uH,'b-+');
legend_entries = char(legend_entries,'High-order');

% plot FCT solution
plot(x,uFCT,'g-x');
switch limiting_option
    case 0 % no correction
        limiter_string = 'no correction';
    case 1 % full correction (no limiting)
        limiter_string = 'not limited';
    case 2 % Kuzmin limiter
        limiter_string = 'Kuzmin limiter';
    case 3 % TAMU limiter
        limiter_string = 'TAMU limiter';
    otherwise
        error('Invalid limiting option');
end
FCT_legend_string = ['FCT, ',limiter_string];
legend_entries = char(legend_entries,FCT_legend_string);

% legend
legend(legend_entries,'Location','Best');