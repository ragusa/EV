function Flim = limiting_coefficients(F,u,AL,kuzmin_or_TAMU)
% computes the limited fluxes
%
% Flim  = limiting coefficient matrix
%
% F     = flux correction matrix
% u     = solution
% AL    = low-order system matrix
% kuzmin_or_tamu = option to use Kuzmin's limiter (1) or TAMU's (2)

n = length(u);

Flim   = zeros(n,n);
Pplus  = zeros(n,1);
Pminus = zeros(n,1);
Rminus = zeros(n,1);
Rplus  = zeros(n,1);
Qminus = zeros(n,1);
Qplus  = zeros(n,1);

% Q vectors
switch kuzmin_or_TAMU
    case 1 % Kuzmin
        % P vectors
        for edge = 1:n-1
            i = edge; % upstream node
            j = i+1;  % downstream node
            
            Pplus(i)  = Pplus(i)  + max(0,F(i,j));
            Pminus(i) = Pminus(i) + min(0,F(i,j));
            
            Qplus(j)  = Qplus(j)  + max(-AL(j,i)*(u(j) - u(i)),0);
            Qminus(j) = Qminus(j) + min(-AL(j,i)*(u(j) - u(i)),0);  
        end
    case 2 % TAMU
        % P vectors
        for i = 1:n
            Pplus(i) = sum(max(0,F(i,:)));
            Pminus(i)= sum(min(0,F(i,:)));
        end
        % Q vectors
        for i = 1:n
            % compute index range of support of i
            i1=max(i-1,1);
            i2=min(i+1,n);
            % compute max and min old solution in the support of each dof
            u_max = max(u(i1:i2));
            u_min = min(u(i1:i2));
            % compute Q
            Qplus(i)  = AL(i,:)*u - AL(i,i)*u(i) - (sum(AL(i,:))-AL(i,i))*u_max;
            Qminus(i) = AL(i,:)*u - AL(i,i)*u(i) - (sum(AL(i,:))-AL(i,i))*u_min;
        end
    otherwise
        error('Invalid option');
end

% R vectors
for i = 1:n
    if (Pplus(i) ~= 0)
        Rplus(i) = min(1, Qplus(i)/Pplus(i));
    else
        Rplus(i) = 1.0;
    end
    if (Pminus(i) ~= 0)
        Rminus(i) = min(1, Qminus(i)/Pminus(i));
    else
        Rminus(i) = 1.0;
    end
end
% set R+ and R- = 1 for Dirichlet node as Kuzmin recommended. This
% prevents L_ij from automatically being 0 for j in the support of i
Rplus(1)  = 1.0;
Rminus(1) = 1.0;

for edge = 1:n-1
    i = edge; % upwind node
    j = i+1;  % downwind node
    if (F(i,j) > 0)
        Flim(i,j) = Rplus(i)*F(i,j);
    else
        Flim(i,j) = Rminus(i)*F(i,j);
    end
    Flim(j,i) = -Flim(i,j);
end

return
end